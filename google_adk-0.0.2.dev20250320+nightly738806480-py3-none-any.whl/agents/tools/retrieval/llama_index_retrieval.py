"""Provides data for the agent."""

from __future__ import annotations

from typing import Any
from typing import TYPE_CHECKING

from typing_extensions import override

from ..tool_context import ToolContext
from .base_retrieval_tool import BaseRetrievalTool

if TYPE_CHECKING:
  from llama_index.core.base.base_retriever import BaseRetriever


class LlamaIndexRetrieval(BaseRetrievalTool):

  def __init__(self, *, name: str, description: str, retriever: BaseRetriever):
    super().__init__(name=name, description=description)
    self.retriever = retriever

  @override
  def _run_sync(self, *, args: dict[str, Any], ctx: ToolContext) -> Any:
    return self.retriever.retrieve(args['query'])[0].text

  @override
  async def run_async(self, *, args: dict[str, Any], ctx: ToolContext) -> Any:
    return self._run_sync(args=args, ctx=ctx)
