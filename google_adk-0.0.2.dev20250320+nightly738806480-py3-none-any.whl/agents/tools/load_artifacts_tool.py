from __future__ import annotations

import json
from typing import Any
from typing import TYPE_CHECKING

from google.genai import types
from typing_extensions import override

from .base_tool import BaseTool

if TYPE_CHECKING:
  from ..models.llm_request import LlmRequest
  from .tool_context import ToolContext


class LoadArtifactsTool(BaseTool):

  def __init__(self):
    super().__init__(
        name='load_artifacts',
        description='Loads the artifacts and adds them to the session.',
    )

  def _get_declaration(self) -> types.FunctionDeclaration | None:
    return types.FunctionDeclaration(
        name=self.name,
        description=self.description,
        parameters=types.Schema(
            type=types.Type.OBJECT,
            properties={
                'artifact_names': types.Schema(
                    type=types.Type.ARRAY,
                    items=types.Schema(
                        type=types.Type.STRING,
                    ),
                )
            },
        ),
    )

  @override
  def _run_sync(self, *, args: dict[str, Any], ctx: ToolContext) -> Any:
    artifact_names: list[str] = args.get('artifact_names', [])
    return {'artifact_names': artifact_names}

  @override
  async def run_async(self, *, args: dict[str, Any], ctx: ToolContext) -> Any:
    return self._run_sync(args=args, ctx=ctx)

  def _process_llm_request_sync(
      self, *, tool_context: ToolContext, llm_request: LlmRequest
  ) -> None:
    super()._process_llm_request_sync(
        tool_context=tool_context,
        llm_request=llm_request,
    )

    self._append_artifacts_to_llm_request(
        tool_context=tool_context, llm_request=llm_request
    )

  @override
  async def process_llm_request(
      self, *, tool_context: ToolContext, llm_request: LlmRequest
  ) -> None:
    await super().process_llm_request(
        tool_context=tool_context,
        llm_request=llm_request,
    )
    self._append_artifacts_to_llm_request(
        tool_context=tool_context, llm_request=llm_request
    )

  def _append_artifacts_to_llm_request(
      self, *, tool_context: ToolContext, llm_request: LlmRequest
  ):
    artifact_names = tool_context.list_artifacts()
    if not artifact_names:
      return

    # Tell the model about the available artifacts.
    llm_request.append_instructions([f"""You have a list of artifacts:
  {json.dumps(artifact_names)}

  When the user asks questions about any of the artifacts, you should call the
  `load_artifacts` function to load the artifact. Do not generate any text other
  than the function call.
  """])

    # Attache the content of the artifacts if the model requests them.
    # This only adds the content to the model request, instead of the session.
    if llm_request.contents and llm_request.contents[-1].parts:
      function_response = llm_request.contents[-1].parts[0].function_response
      if function_response and function_response.name == 'load_artifacts':
        artifact_names = function_response.response['artifact_names']
        for artifact_name in artifact_names:
          artifact = tool_context.load_artifact(artifact_name)
          llm_request.contents.append(
              types.Content(
                  role='user',
                  parts=[
                      types.Part.from_text(
                          text=f'Artifact {artifact_name} is:'
                      ),
                      artifact,
                  ],
              )
          )


load_artifacts_tool = LoadArtifactsTool()
