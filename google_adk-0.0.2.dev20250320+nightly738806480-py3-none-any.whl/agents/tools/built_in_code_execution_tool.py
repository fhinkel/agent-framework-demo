from __future__ import annotations

from typing import TYPE_CHECKING

from google.genai import types
from typing_extensions import override

from .base_tool import BaseTool
from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models import LlmRequest


class BuiltInCodeExecutionTool(BaseTool):

  def __init__(self):
    # Name and description are not used because this is a model built-in tool.
    super().__init__(name='code_execution', description='code_execution')

  @override
  def _process_llm_request_sync(
      self,
      *,
      tool_context: ToolContext,
      llm_request: LlmRequest,
  ) -> None:
    if llm_request.model and llm_request.model.startswith('gemini-2'):
      llm_request.config = llm_request.config or types.GenerateContentConfig()
      llm_request.config.tools = llm_request.config.tools or []
      llm_request.config.tools.append(
          types.Tool(code_execution=types.ToolCodeExecution())
      )
    else:
      raise ValueError(
          f'Code execution tool is not supported for model {llm_request.model}'
      )

  @override
  async def process_llm_request(
      self,
      *,
      tool_context: ToolContext,
      llm_request: LlmRequest,
  ) -> None:
    self._process_llm_request_sync(
        tool_context=tool_context, llm_request=llm_request
    )


built_in_code_execution_tool = BuiltInCodeExecutionTool()
