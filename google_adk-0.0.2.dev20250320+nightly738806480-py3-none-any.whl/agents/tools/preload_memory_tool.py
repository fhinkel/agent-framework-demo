from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from typing_extensions import override

from .base_tool import BaseTool
from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models import LlmRequest


class PreloadMemoryTool(BaseTool):

  def __init__(self):
    # Name and description are not used because this tool only
    # changes llm_request.
    super().__init__(name='preload_memory', description='preload_memory')

  @override
  def _process_llm_request_sync(
      self,
      *,
      tool_context: ToolContext,
      llm_request: LlmRequest,
  ) -> None:
    parts = tool_context.user_content.parts
    if not parts or not parts[0].text:
      return
    query = parts[0].text
    response = tool_context.search_memory(query)
    if not response.memories:
      return
    memory_text = ''
    for memory in response.memories:
      time_str = datetime.fromtimestamp(memory.events[0].timestamp).isoformat()
      memory_text += f'Time: {time_str}\n'
      for event in memory.events:
        # TODO: support multi-part content.
        if (
            event.content
            and event.content.parts
            and event.content.parts[0].text
        ):
          memory_text += f'{event.author}: {event.content.parts[0].text}\n'
    si = f"""The following content is from your previous conversations with the user.
They may be useful for answering the user's current query.
<PAST_CONVERSATIONS>
{memory_text}
</PAST_CONVERSATIONS>
"""
    llm_request.append_instructions([si])

  @override
  async def process_llm_request(
      self,
      *,
      tool_context: ToolContext,
      llm_request: LlmRequest,
  ) -> None:
    self._process_llm_request_sync(
        tool_context=tool_context, llm_request=llm_request
    )


preload_memory_tool = PreloadMemoryTool()
