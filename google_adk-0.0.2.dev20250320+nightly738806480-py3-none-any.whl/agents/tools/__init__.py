from .auth_tool import AuthToolArguments
from .base_tool import BaseTool
from .built_in_code_execution_tool import built_in_code_execution_tool as built_in_code_execution
from .built_in_google_search_tool import built_in_google_search_tool as built_in_google_search
from .example_tool import ExampleTool
from .function_tool import FunctionTool
from .get_user_choice_tool import get_user_choice_tool as get_user_choice
from .load_artifacts_tool import load_artifacts_tool as load_artifacts
from .load_memory_tool import load_memory_tool as load_memory
from .long_running_tool import LongRunningFunctionTool
from .preload_memory_tool import preload_memory_tool as preload_memory
from .tool_context import ToolContext

__all__ = [
    'AuthToolArguments',
    'BaseTool',
    'built_in_code_execution',
    'built_in_google_search',
    'ExampleTool',
    'FunctionTool',
    'get_user_choice',
    'load_artifacts',
    'load_memory',
    'LongRunningFunctionTool',
    'preload_memory',
    'ToolContext',
]


def exit_loop(tool_context: ToolContext):
  """Exits the loop.

  Call this function only when you are instructed to do so.
  """
  tool_context.actions.escalate = True


# TODO: make this internal, since user doesn't need to use this tool directly.
def transfer_to_agent(agent_name: str, tool_context: ToolContext):
  """Transfer the question to another agent."""
  tool_context.actions.transfer_to_agent = agent_name
