from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Union

from pydantic import TypeAdapter
from typing_extensions import override

from ..examples import example_util
from ..examples.base_example_provider import BaseExampleProvider
from ..examples.example import Example
from .base_tool import BaseTool
from .tool_context import ToolContext

if TYPE_CHECKING:
  from ..models.llm_request import LlmRequest


class ExampleTool(BaseTool):

  def __init__(self, examples: Union[list[Example], BaseExampleProvider]):
    # Name and description are not used because this tool only changes
    # llm_request.
    super().__init__(name='example_tool', description='example tool')
    self.examples = (
        TypeAdapter(list[Example]).validate_python(examples)
        if isinstance(examples, list)
        else examples
    )

  @override
  def _process_llm_request_sync(
      self, *, tool_context: ToolContext, llm_request: LlmRequest
  ) -> None:
    parts = tool_context.user_content.parts
    if not parts or not parts[0].text:
      return

    llm_request.append_instructions(
        [example_util.build_example_si(self.examples, parts[0].text)]
    )

  @override
  async def process_llm_request(
      self,
      *,
      tool_context: ToolContext,
      llm_request: LlmRequest,
  ) -> None:
    self._process_llm_request_sync(
        tool_context=tool_context, llm_request=llm_request
    )
