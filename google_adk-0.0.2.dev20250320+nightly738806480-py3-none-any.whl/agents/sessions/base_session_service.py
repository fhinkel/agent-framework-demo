import abc
from typing import Any
from typing import Optional

from pydantic import BaseModel

from ..events.event import Event
from .session import Session
from .state import State


class GetSessionConfig(BaseModel):
  num_recent_events: Optional[int] = None
  after_timestamp: Optional[float] = None


class ListEventsConfig(BaseModel):
  query: Optional[str] = None
  page_size: Optional[int] = None
  page_token: Optional[str] = None


class ListSessionsResponse(BaseModel):
  session_ids: list[str] = []


class ListEventsResponse(BaseModel):
  events: list[Event] = []
  next_page_token: Optional[str] = None


class BaseSessionService(abc.ABC):

  @abc.abstractmethod
  def create_session(
      self,
      app_name: str,
      user_id: str,
      state: Optional[dict[str, Any]] = None,
      *,
      session_id: Optional[str] = None,
  ) -> Session:
    """Creates a new session.

    Args:
      app_name: the name of the app.
      user_id: the id of the user.
      state: the initial state of the session.
      session_id: the client-provided id of the session. If not provided, a
        server-side generated uuid will be used.

    Returns:
      session: The newly created session instance.
    """
    pass

  @abc.abstractmethod
  def get_session(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: Optional[GetSessionConfig] = None,
  ) -> Optional[Session]:
    """Gets a session."""
    pass

  @abc.abstractmethod
  def list_sessions(self, app_name: str, user_id: str) -> ListSessionsResponse:
    """Lists all the session IDs."""
    pass

  @abc.abstractmethod
  def delete_session(
      self, app_name: str, user_id: str, session_id: str
  ) -> None:
    """Deletes a session."""
    pass

  @abc.abstractmethod
  def list_events(
      self,
      app_name: str,
      user_id: str,
      session_id: str,
      config: ListEventsConfig,
  ) -> ListEventsResponse:
    """Lists events in a session."""
    pass

  def close_session(self, session: Session):
    """Closes a session."""
    # TODO: determine whether we want to finalize the session here.
    pass

  def append_event(self, session: Session, event: Event) -> Event:
    """Appends an event to a session."""
    if event.partial:
      return event
    if event.actions:
      if event.actions.state_delta:
        updates = event.actions.state_delta
        for key in updates:
          if not key.startswith(State.TEMP_PREFIX):
            session.state.update({key: updates[key]})

    session.events.append(event)
    return event
