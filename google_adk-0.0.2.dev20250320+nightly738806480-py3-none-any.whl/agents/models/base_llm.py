import abc
from abc import abstractmethod
from typing import AsyncGenerator
from typing import Generator

from pydantic import BaseModel
from pydantic import ConfigDict

from .base_llm_connection import BaseLlmConnection
from .llm_request import LlmRequest
from .llm_response import LlmResponse


class BaseLlm(BaseModel):
  """The BaseLLM class."""

  model_config = ConfigDict(
      # This allows us to use arbitrary types in the model. E.g. PIL.Image.
      arbitrary_types_allowed=True,
  )

  model: str
  """The name of the LLM, e.g. gemini-1.5-flash or gemini-1.5-flash-001."""

  @staticmethod
  @abstractmethod
  def supported_models() -> list[str]:
    """Returns a list of supported models in regex."""
    pass

  @abc.abstractmethod
  def generate_content(
      self, llm_request: LlmRequest, stream: bool = False
  ) -> Generator[LlmResponse, None, None]:
    """Generates one content from the given contents and tools.

    Args:
      llm_request: LlmRequest, the request to send to the LLM.
      stream: bool = False, whether to do streaming call.

    Returns a generator of LlmResponse. For non-streaming call, it will only
      yield one LlmResponse. For streaming call, it may yield more than one
      LlmResponse, but all yielded contents should be treated as one content by
      merging the parts list.
    """
    raise NotImplementedError(
        f'Async generation is not supported for {self.model}.'
    )
    yield  # Generator requires a yield statement in function body.

  # TODO(weisun): mark this as abstractmethod after adding it all subclass.
  async def generate_content_async(
      self, llm_request: LlmRequest, stream: bool = False
  ) -> AsyncGenerator[LlmResponse, None]:
    """Generates one content from the given contents and tools.

    Args:
      llm_request: LlmRequest, the request to send to the LLM.
      stream: bool = False, whether to do streaming call.

    Returns a generator of types.Content. For non-streaming call, it will only
      yield one Content. For streaming call, it may yield more than one content,
      but all yielded contents should be treated as one content by merging the
      parts list.
    """
    raise NotImplementedError(
        f'Async generation is not supported for {self.model}.'
    )
    yield  # AsyncGenerator requires a yield statement in function body.

  def connect(self, llm_request: LlmRequest) -> BaseLlmConnection:
    """Creates a live connection to the LLM."""
    raise NotImplementedError(
        f'Live connection is not supported for {self.model}.'
    )
