"""The registry class for model."""

from __future__ import annotations

import logging
import re
from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
  from .base_llm import BaseLlm

logger = logging.getLogger(__name__)


_llm_registry_dict: dict[str, type[BaseLlm]] = {}
"""Registry for LLMs.

Key is the regex that matches the model name.
Value is the class that implements the model.
"""


class LLMRegistry:
  """Registry for LLMs."""

  @staticmethod
  def new_llm(model: str) -> BaseLlm:
    return LLMRegistry.resolve(model)(model=model)

  @staticmethod
  def _register(model_name_regex: str, llm_cls: type[BaseLlm]):
    if model_name_regex in _llm_registry_dict:
      logger.info(
          'Updating LLM class for %s from %s to %s',
          model_name_regex,
          _llm_registry_dict[model_name_regex],
          llm_cls,
      )

    _llm_registry_dict[model_name_regex] = llm_cls

  @staticmethod
  def register(llm_cls: type[BaseLlm]):
    for regex in llm_cls.supported_models():
      LLMRegistry._register(regex, llm_cls)

  @staticmethod
  @lru_cache(maxsize=32)
  def resolve(model: str) -> type[BaseLlm]:
    for regex, llm_class in _llm_registry_dict.items():
      if re.compile(regex).fullmatch(model):
        return llm_class

    raise ValueError(f'Model {model} not found.')
