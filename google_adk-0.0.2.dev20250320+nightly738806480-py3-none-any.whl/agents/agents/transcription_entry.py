from typing import Union

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict


class TranscriptionEntry(BaseModel):
  """Store the data that can be used for transcription."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  role: str
  """The role that created this data, typically "user" or "model"""

  data: Union[types.Blob, types.Content]
  """The data that can be used for transcription"""
