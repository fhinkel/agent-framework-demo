import asyncio
from typing import Optional

from google.genai import types
from pydantic import BaseModel
from pydantic import ConfigDict

from .live_request_queue import LiveRequestQueue

class ActiveStreamingTool(BaseModel):
  """Manages streaming tool related resources during invocation."""

  model_config = ConfigDict(
      arbitrary_types_allowed=True,
      extra='forbid',
  )

  task: Optional[asyncio.Task] = None
  """The active task of this streaming tool."""

  stream: Optional[LiveRequestQueue] = None
  """The active (input) streams of this streaming tool."""
