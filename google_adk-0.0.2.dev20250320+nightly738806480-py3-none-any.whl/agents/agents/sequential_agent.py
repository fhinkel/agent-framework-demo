"""Sequential agent implementation."""

from __future__ import annotations

from typing import AsyncGenerator

from typing_extensions import override

from ..agents.invocation_context import InvocationContext
from ..events import Event
from .base_agent import BaseAgent


class SequentialAgent(BaseAgent):
  """A shell agent that run its child agents in sequence."""

  @override
  async def _run_async_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    for child in self.children:
      async for event in child.run_async(ctx):
        yield event

  @override
  async def _run_live_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    for child in self.children:
      async for event in child.run_live(ctx):
        yield event
