"""Loop agent implementation."""

from __future__ import annotations

from typing import AsyncGenerator
from typing import Optional

from typing_extensions import override

from ..agents.invocation_context import InvocationContext
from ..events import Event
from .base_agent import BaseAgent


class LoopAgent(BaseAgent):
  """A shell agent that run its child agents in a loop.

  When child agent generates an event with escalate or max_iterations are
  reached, the loop agent will stop.
  """

  max_iterations: Optional[int] = None
  """The maximum number of iterations to run the loop agent.

  If not set, the loop agent will run indefinitely until a child agent
  escalates.
  """

  @override
  async def _run_async_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    times_looped = 0
    while not self.max_iterations or times_looped < self.max_iterations:
      for child in self.children:
        async for event in child.run_async(ctx):
          yield event
          if event.actions.escalate:
            return
      times_looped += 1
    return

  @override
  async def _run_live_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    raise NotImplementedError('The behavior for run_live is not defined yet.')
    yield  # AsyncGenerator requires having at least one yield statement
