import json
from typing import AsyncGenerator

from pydantic import Field
import requests
from typing_extensions import override

from ..events import Event
from .base_agent import BaseAgent
from .invocation_context import InvocationContext


class RemoteAgent(BaseAgent):
  """Experimental, do not use."""

  url: str

  children: list[BaseAgent] = Field(
      default_factory=list, init=False, frozen=True
  )

  @override
  async def _run_async_impl(
      self, ctx: InvocationContext
  ) -> AsyncGenerator[Event, None]:
    data = {
        'invocation_id': ctx.invocation_id,
        'session': ctx.session.model_dump(exclude_none=True),
    }
    events = requests.post(self.url, data=json.dumps(data))
    events.raise_for_status()
    for event in events.json():
      e = Event.model_validate(event)
      e.author = self.name
      yield e
