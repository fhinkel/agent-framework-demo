import logging
from .base_code_executor import BaseCodeExecutor
from .code_execution_utils import CodeExecutionInput
from .code_execution_utils import CodeExecutionResult
from .code_execution_utils import CodeExecutionUtils
from .code_execution_utils import File
from .code_executor_context import CodeExecutorContext
from .unsafe_local_code_executor import UnsafeLocalCodeExecutor

logger = logging.getLogger(__name__)

__all__ = [
    'BaseCodeExecutor',
    'CodeExecutionInput',
    'CodeExecutionResult',
    'CodeExecutionUtils',
    'CodeExecutorContext',
    'File',
    'UnsafeLocalCodeExecutor',
]

try:
  from .vertex_ai_code_executor import VertexAiCodeExecutor

  __all__.append('vertex_ai_code_executor')
except ImportError:
  logger.warning(
      'The Vertex sdk is not installed. If you want to use the Vertex Code'
      ' Interpreter with agents, please install it. If not, you can ignore this'
      ' warning.'
  )

try:
  from .container_code_executor import ContainerCodeExecutor

  __all__.append('container_code_executor')
except ImportError:
  logger.warning(
      'The docker sdk is not installed. If you want to use the Container Code'
      ' Executor with agents, please install it. If not, you can ignore this'
      ' warning.'
  )
