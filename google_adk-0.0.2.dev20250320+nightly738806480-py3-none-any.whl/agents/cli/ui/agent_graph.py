from typing import Union

from agents.agents import BaseAgent
from agents.agents.llm_agent import LlmAgent
from agents.tools.agent_tool import AgentTool
from agents.tools.base_tool import BaseTool
from agents.tools.function_tool import FunctionTool
from agents.tools.retrieval.base_retrieval_tool import BaseRetrievalTool
import graphviz


def build_graph(graph, agent: BaseAgent, highlight_pairs):
  dark_green = '#6aa84f'
  light_green = '#d9ead3'

  def get_node_name(tool_or_agent: Union[BaseAgent, BaseTool]):
    if isinstance(tool_or_agent, BaseAgent):
      return tool_or_agent.name
    elif isinstance(tool_or_agent, BaseTool):
      return tool_or_agent.name
    else:
      raise ValueError(f'Unsupported tool type: {tool_or_agent}')

  def get_node_caption(tool_or_agent: Union[BaseAgent, BaseTool]):
    if isinstance(tool_or_agent, BaseAgent):
      return '🤖 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, BaseRetrievalTool):
      return '🔎 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, FunctionTool):
      return '🔧 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, AgentTool):
      return '🤖 ' + tool_or_agent.name
    elif isinstance(tool_or_agent, BaseTool):
      return '🔧 ' + tool_or_agent.name
    else:
      raise ValueError(f'Unsupported tool type: {type(tool)}')

  def get_node_shape(tool_or_agent: Union[BaseAgent, BaseTool]):
    if isinstance(tool_or_agent, BaseAgent):
      return 'ellipse'
    elif isinstance(tool_or_agent, BaseRetrievalTool):
      return 'cylinder'
    elif isinstance(tool_or_agent, FunctionTool):
      return 'box'
    elif isinstance(tool_or_agent, BaseTool):
      return 'box'
    else:
      raise ValueError(f'Unsupported tool type: {type(tool_or_agent)}')

  def draw_node(tool_or_agent: Union[BaseAgent, BaseTool]):
    name = get_node_name(tool_or_agent)
    shape = get_node_shape(tool_or_agent)
    caption = get_node_caption(tool_or_agent)
    if highlight_pairs:
      for highlight_tuple in highlight_pairs:
        if name in highlight_tuple:
          graph.node(
              name,
              caption,
              style='filled,rounded',
              fillcolor=light_green,
              color=dark_green,
              shape=shape,
          )
          return
    # if not in highlight, draw non-highliht node
    graph.node(name, caption, shape=shape, style='rounded')

  def draw_edge(from_name, to_name):
    if highlight_pairs:
      for highlight_from, highlight_to in highlight_pairs:
        if from_name == highlight_from and to_name == highlight_to:
          graph.edge(from_name, to_name, color=dark_green)
          return
        elif from_name == highlight_to and to_name == highlight_from:
          graph.edge(from_name, to_name, color=dark_green, dir='back')
          return
    # if no need to highlight, color none
    graph.edge(from_name, to_name, arrowhead='none')

  draw_node(agent)
  for child in agent.children:
    build_graph(graph, child, highlight_pairs)
    draw_edge(agent.name, child.name)
  if isinstance(agent, LlmAgent):
    for tool in agent.canonical_tools:
      draw_node(tool)
      draw_edge(agent.name, get_node_name(tool))


def get_agent_graph(root_agent, highlights_pairs):
  print('build graph')
  graph = graphviz.Digraph(graph_attr={'rankdir': 'LR'})
  build_graph(graph, root_agent, highlights_pairs)
  return graph
