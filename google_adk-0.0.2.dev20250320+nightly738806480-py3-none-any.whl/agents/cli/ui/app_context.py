import os
import sys
import time
import types
from typing import Any

from agents.agents.invocation_context import new_invocation_context_id
from agents.agents.llm_agent import Agent
from agents.artifacts import InMemoryArtifactService
from agents.cli.utils import envs
from agents.events.event import Event
from agents.events.event_actions import EventActions
from agents.memory.in_memory_memory_service import InMemoryMemoryService
from agents.runners import Runner
from agents.sessions.base_session_service import BaseSessionService
from agents.sessions.database_session_service import DatabaseSessionService
from agents.sessions.in_memory_session_service import InMemorySessionService
from agents.sessions.session import Session
from agents.sessions.vertex_ai_session_service import VertexAiSessionService
import streamlit as st

CONNECT_REMOTE_SERVER_DEMO_NAME = 'Connect to Remote Server'


@st.cache_resource
def get_remote_server_urls():
  remote_urls = set()
  return remote_urls


@st.cache_resource
def get_session_service() -> BaseSessionService:
  if st.session_state.agent_engine_id:
    envs.load_dotenv_for_agent(
        st.session_state.demo_name if st.session_state.demo_name else '',
        get_agent_folder(),
    )
    return VertexAiSessionService(
        os.environ['GOOGLE_CLOUD_PROJECT'], os.environ['GOOGLE_CLOUD_LOCATION']
    )

  db_url = sys.argv[2]
  if db_url:
    return DatabaseSessionService(db_url=db_url)
  else:
    return InMemorySessionService()


@st.cache_resource
def get_artifact_service():
  return InMemoryArtifactService()


@st.cache_resource
def get_memory_service():
  return InMemoryMemoryService()


def update_session_state(new_states: dict[str, Any]):
  session: Session = st.session_state.session
  get_session_service().append_event(
      session,
      Event(
          invocation_id=new_invocation_context_id(),
          author='user',
          actions=EventActions(state_delta=new_states),
      ),
  )


def _get_runner(agent_name: str):
  reasoning_engine_id = st.session_state.agent_engine_id
  return Runner(
      app_name=reasoning_engine_id if reasoning_engine_id else agent_name,
      agent=get_demo_modules()[agent_name].agent.root_agent,
      artifact_service=get_artifact_service(),
      session_service=get_session_service(),
      memory_service=get_memory_service(),
      response_modalities=st.session_state.response_modalities,
  )


def get_runner() -> Runner:
  """Gets the runner for the current selected agent."""
  return _get_runner(_get_root_agent_name())


@st.cache_resource
def get_agent_folder():
  agent_folder = sys.argv[1]
  if agent_folder not in sys.path:
    sys.path.append(agent_folder)
  return agent_folder


@st.cache_resource
def get_demo_modules() -> dict[str, types.ModuleType]:
  demo_modules = {}
  return demo_modules


def setup_session_state():
  if 'agent_engine_id' not in st.session_state:
    st.session_state.agent_engine_id = sys.argv[3]
  if 'event_dialog_index' not in st.session_state:
    st.session_state.event_dialog_index = 0
  if 'file_uploader_key' not in st.session_state:
    st.session_state.file_uploader_key = str(time.time())
  if 'event_num' not in st.session_state:
    st.session_state.event_num = 0
  if 'edit_state' not in st.session_state:
    st.session_state.edit_state = False
  if 'demo_name' not in st.session_state:
    st.session_state.demo_name = None
  if 'streaming' not in st.session_state:
    st.session_state.streaming = None
  if 'call_llm_spans' not in st.session_state:
    st.session_state.call_llm_spans = {}
  if 'is_live' not in st.session_state:
    st.session_state.is_live = False
  if 'response_modalities' not in st.session_state:
    st.session_state.response_modalities = None
  if 'artifact_service' not in st.session_state:
    st.session_state.artifact_service = get_artifact_service()
  if 'session_service' not in st.session_state:
    st.session_state.session_service = get_session_service()


def _get_root_agent_name() -> str:
  return st.session_state.demo_name


def get_root_agent() -> Agent:
  return get_demo_modules()[_get_root_agent_name()].agent.root_agent


def is_remote_mode() -> bool:
  """Whether it's running in remote mode via an api server."""
  demo_name: str = st.session_state.demo_name
  return bool(demo_name) and demo_name.startswith('http://')
