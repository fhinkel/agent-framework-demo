"""Defines the processor interface used for BaseLlmFlow."""

from abc import ABC
from abc import abstractmethod
from typing import AsyncGenerator
from typing import Generator

from deprecated import deprecated

from ...agents.invocation_context import InvocationContext
from ...events.event import Event
from ...models.llm_request import LlmRequest
from ...models.llm_response import LlmResponse


class BaseLlmRequestProcessor(ABC):

  @deprecated(reason="Only remain for sync code path, will be removed soon.")
  @abstractmethod
  def run_sync(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> Generator[Event, None, None]:
    """Run the processor in sync mode."""

  @abstractmethod
  async def run_async(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> AsyncGenerator[Event, None]:
    """Runs the processor."""
    raise NotImplementedError("Not implemented.")
    yield  # AsyncGenerator requires a yield in function body.


class BaseLlmResponseProcessor(ABC):
  """Base class for LLM response processor."""

  @deprecated(reason="Only remain for sync code path, will be removed soon.")
  @abstractmethod
  def run_sync(
      self, invocation_context: InvocationContext, llm_response: LlmResponse
  ) -> Generator[Event, None, None]:
    """Processes the LLM response in sync mode."""

  @abstractmethod
  async def run_async(
      self, invocation_context: InvocationContext, llm_response: LlmResponse
  ) -> AsyncGenerator[Event, None]:
    """Processes the LLM response."""
    raise NotImplementedError("Not implemented.")
    yield  # AsyncGenerator requires a yield in function body.
