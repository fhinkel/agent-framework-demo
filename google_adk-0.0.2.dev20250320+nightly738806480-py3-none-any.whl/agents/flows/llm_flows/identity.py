"""Gives the agent identity from the framework."""

from __future__ import annotations

from typing import AsyncGenerator
from typing import Generator

from typing_extensions import override

from ...agents.invocation_context import InvocationContext
from ...events.event import Event
from ...models import LlmRequest
from ._base_llm_processor import BaseLlmRequestProcessor


class _IdentityLlmRequestProcessor(BaseLlmRequestProcessor):

  @override
  def run_sync(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> Generator[Event, None, None]:
    agent = invocation_context.agent
    si = [f'You are an agent. Your internal name is "{agent.name}".']
    if agent.description:
      si.append(f' The description about you is "{agent.description}"')
    llm_request.append_instructions(si)

    yield from []  # Generator requires yield statement in function body.

  @override
  async def run_async(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> AsyncGenerator[Event, None]:
    for event in self.run_sync(invocation_context, llm_request):
      yield event


request_processor = _IdentityLlmRequestProcessor()
