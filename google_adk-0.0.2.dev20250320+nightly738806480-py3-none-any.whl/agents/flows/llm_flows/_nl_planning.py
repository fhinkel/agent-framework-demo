"""Handles NL planning related logic."""

from __future__ import annotations

from typing import AsyncGenerator
from typing import Generator
from typing import Optional

from typing_extensions import override

from ...agents.callback_context import CallbackContext
from ...agents.invocation_context import InvocationContext
from ...agents.readonly_context import ReadonlyContext
from ...events.event import Event
from ...models import LlmRequest
from ...models import LlmResponse
from ...planner.base_planner import BasePlanner
from ...planner.plan_re_act_planner import PlanReActPlanner
from ._base_llm_processor import BaseLlmRequestProcessor
from ._base_llm_processor import BaseLlmResponseProcessor


class _NlPlanningRequestProcessor(BaseLlmRequestProcessor):
  """Processor for NL planning."""

  @override
  def run_sync(
      self,
      invocation_context: InvocationContext,
      llm_request: LlmRequest,
  ) -> Generator[Event, None, None]:
    planner = _get_planner(invocation_context)
    if not planner:
      return

    planning_instruction = planner.build_planning_instruction(
        ReadonlyContext(invocation_context), llm_request
    )
    if planning_instruction:
      llm_request.append_instructions([planning_instruction])

    _remove_thought_from_request(llm_request)

    yield from []  # Generator requires yield statement in function body.

  async def run_async(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> AsyncGenerator[Event, None]:
    for event in self.run_sync(invocation_context, llm_request):
      yield event


request_processor = _NlPlanningRequestProcessor()


class _NlPlanningResponse(BaseLlmResponseProcessor):

  @override
  def run_sync(
      self,
      invocation_context: InvocationContext,
      llm_response: LlmResponse,
  ) -> Generator[Event, None, None]:
    if (
        not llm_response
        or not llm_response.content
        or not llm_response.content.parts
    ):
      return

    planner = _get_planner(invocation_context)
    if not planner:
      return

    # Postprocess the LLM response.
    processed_parts = planner.process_planning_response(
        CallbackContext(invocation_context), llm_response.content.parts
    )
    if processed_parts:
      llm_response.content.parts = processed_parts

    yield from []  # Generator requires yield statement in function body.

  @override
  async def run_async(
      self, invocation_context: InvocationContext, llm_response: LlmResponse
  ) -> AsyncGenerator[Event, None]:
    for event in self.run_sync(invocation_context, llm_response):
      yield event


response_processor = _NlPlanningResponse()


def _get_planner(
    invocation_context: InvocationContext,
) -> Optional[BasePlanner]:
  from ...agents.llm_agent import Agent

  agent = invocation_context.agent
  if not isinstance(agent, Agent):
    return None
  if not agent.planner:
    return None

  if isinstance(agent.planner, BasePlanner):
    return agent.planner
  return PlanReActPlanner()


def _remove_thought_from_request(llm_request: LlmRequest):
  if not llm_request.contents:
    return

  for content in llm_request.contents:
    if not content.parts:
      continue
    for part in content.parts:
      part.thought = None
