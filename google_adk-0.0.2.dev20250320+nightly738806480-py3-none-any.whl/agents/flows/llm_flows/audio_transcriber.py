from google.cloud import speech
from google.genai import types as genai_types


class AudioTranscriber:

  def __init__(self):
    self.client = speech.SpeechClient()

  def transcribe_file(self, invocation_context) -> list[genai_types.Content]:
    """Transcribe audio, bundling consecutive segments from the same speaker.

    The ordering of speakers will be preserved. Audio blobs will be merged for
    the same speaker as much as we can do reduce the transcription latency.
    """

    bundled_audio = []
    current_speaker = None
    current_audio_data = b''
    contents = []

    # Step1: merge audio blobs
    for transcription_entry in invocation_context.transcription_cache:
      speaker, audio_data = (
          transcription_entry.role,
          transcription_entry.data,
      )

      if isinstance(audio_data, genai_types.Content):
        if current_speaker is not None:
          bundled_audio.append((current_speaker, current_audio_data))
          current_speaker = None
          current_audio_data = b''
        bundled_audio.append((speaker, audio_data))
        continue

      if speaker == current_speaker:
        current_audio_data += audio_data.data
      else:
        if current_speaker is not None:
          bundled_audio.append((current_speaker, current_audio_data))
        current_speaker = speaker
        current_audio_data = audio_data.data

    # Append the last audio segment if any
    if current_speaker is not None:
      bundled_audio.append((current_speaker, current_audio_data))

    # reset cache
    invocation_context.transcription_cache = []

    # Step2: transcription
    for speaker, data in bundled_audio:
      if speaker == 'user':
        audio = speech.RecognitionAudio(content=data)

        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=16000,
            language_code='en-US',
        )

        response = self.client.recognize(config=config, audio=audio)

        for result in response.results:
          transcript = result.alternatives[0].transcript

          parts = [genai_types.Part(text=transcript)]
          role = speaker.lower()
          content = genai_types.Content(role=role, parts=parts)
          contents.append(content)
      else:
        # don't need to transcribe model which are already text
        contents.append(data)

    return contents
