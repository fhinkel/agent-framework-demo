"""Handles basic information to build the LLM request."""

from __future__ import annotations

from typing import AsyncGenerator
from typing import Generator

from typing_extensions import override

from ...agents.invocation_context import InvocationContext
from ...events.event import Event
from ...models import LlmRequest
from ...tools import AuthToolArguments
from . import functions
from ._base_llm_processor import BaseLlmRequestProcessor
from .functions import REQUEST_EUC_FUNCTION_CALL_NAME


class _AuthLlmRequestProcessor(BaseLlmRequestProcessor):

  @override
  def run_sync(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> Generator[Event, None, None]:
    events = invocation_context.session.events
    if not events:
      return
    request_euc_function_call_response_event = events[-1]
    responses = (
        request_euc_function_call_response_event.get_function_responses()
    )
    if not responses:
      return

    auth_responses_by_long_running_tool_id = {}

    for function_call_response in responses:
      if function_call_response.name != REQUEST_EUC_FUNCTION_CALL_NAME:
        continue

      # found the function call response for the system long running request euc
      # function call
      auth_responses_by_long_running_tool_id[function_call_response.id] = (
          function_call_response.response
      )
    if not auth_responses_by_long_running_tool_id:
      return

    for i in range(len(events) - 2, -1, -1):
      event = events[i]
      # looking for the system long running reqeust euc function call
      function_calls = event.get_function_calls()
      if not function_calls:
        continue

      auth_responses_by_tool_id = {}

      for function_call in function_calls:
        if function_call.id not in auth_responses_by_long_running_tool_id:
          continue
        args = AuthToolArguments.model_validate(function_call.args)

        function_call_id = args.function_call_id
        auth_responses_by_tool_id[function_call_id] = (
            auth_responses_by_long_running_tool_id[function_call.id]
        )
      if not auth_responses_by_tool_id:
        continue
      # found the the system long running reqeust euc function call
      # looking for original function call that requests euc
      for j in range(i - 1, -1, -1):
        event = events[j]
        function_calls = event.get_function_calls()
        if not function_calls:
          continue
        for function_call in function_calls:
          if function_call.id in auth_responses_by_tool_id:
            function_response_event = functions.handle_function_calls(
                invocation_context,
                event,
                llm_request.tools_dict,
                # there could be parallel function calls that require auth
                # auth response would be a dict keyed by function call id
                auth_responses_by_tool_id,
            )
          if function_response_event:
            yield function_response_event
          return
      return

  @override
  async def run_async(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> AsyncGenerator[Event, None]:
    for event in self.run_sync(invocation_context, llm_request):
      yield event


request_processor = _AuthLlmRequestProcessor()
