"""Implementation of single flow."""

import logging

from . import _code_execution
from . import _nl_planning
from . import auth
from . import basic
from . import contents
from . import identity
from . import instructions
from .base_llm_flow import BaseLlmFlow

logger = logging.getLogger(__name__)


class SingleFlow(BaseLlmFlow):
  """SingleFlow is the LLM flows that handles tools calls.

  A single flow only consider an agent itself and tools.
  No children agents are allowed for unit flow.
  """

  def __init__(self):
    super().__init__()
    self.request_processors += [
        basic.request_processor,
        auth.request_processor,
        instructions.request_processor,
        identity.request_processor,
        _nl_planning.request_processor,
        contents.request_processor,
        # Code execution should be after the contents as it mutates the contents
        # to optimize data files.
        _code_execution.request_processor,
    ]
    self.response_processors += [
        _nl_planning.response_processor,
        _code_execution.response_processor,
    ]
